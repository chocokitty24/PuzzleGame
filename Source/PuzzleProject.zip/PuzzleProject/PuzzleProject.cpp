// Copyright 1998-2015 Epic Games, Inc. All Rights Reserved.

#include "PuzzleProject.h"


IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, PuzzleProject, "PuzzleProject");



 